import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() {}

  register(user: any): boolean {
    if (localStorage.getItem(user.username)) {
      return false; // user already exists
    }
    localStorage.setItem(user.username, JSON.stringify(user));
    return true;
  }
  

  login(username: string, password: string): boolean {
    const storedUser = localStorage.getItem(username);
    if (!storedUser) return false;

    const user = JSON.parse(storedUser);
    if (user.password === password) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      return true;
    }
    return false;
  }

  getCurrentUser(): any {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
  }

  logout() {
    localStorage.removeItem('currentUser');
  }
}